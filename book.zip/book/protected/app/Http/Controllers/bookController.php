<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\book;
use App\Models\Autor;
use App\Models\Publisher;

class bookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $data;
    public function index()
    {
        $this->data['datas'] = Book::paginate(15);
        return view('frontend/pages/book/index')->with($this->data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->data['autors'] = Autor::all();
        $this->data['publishers'] = Publisher::all();
        return view('frontend/pages/book/add')->with($this->data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        if (isset($req->id)) {
            $db = Book::find($req->id);
        }else{
            $db = new Book;
        }

        $db->title = $req->title;
        $db->autor_id = $req->autor;
        $db->publisher_id = $req->publisher;
        $db->sinopsis = $req->sinopsis;

        $db->save();

        return redirect('book');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->data['autors'] = Autor::all();
        $this->data['publishers'] = Publisher::all();
        $this->data['data'] = Book::find($id);
        
        return view('frontend/pages/book/add')->with($this->data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Book::destroy($id);
    }
}
