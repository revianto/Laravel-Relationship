<?php

namespace App\Models;

use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Model;

class autor extends Model
{
    protected $fillable = ['name', 'contact', 'email', 'address'];

    public $timestamps = false;

    use HasSlug;

    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    public function book()
    {
    	return $this->hasMany('App\Models\book', 'autor_id');
    }
}
