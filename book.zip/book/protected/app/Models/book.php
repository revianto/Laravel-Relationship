<?php

namespace App\Models;

use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Model;

class book extends Model
{
    use HasSlug;
 
 	protected $fillable = ['title', 'autor_id', 'publisher_id', 'sinopsis'];

 	public $timestamps = true;

 	public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('title')
            ->saveSlugsTo('slug');
    }

    public function autor()
    {
    	return $this->belongsTo('App\Models\autor');
    }

    public function publisher()
    {
    	return $this->belongsTo('App\Models\publisher');
    }
}
