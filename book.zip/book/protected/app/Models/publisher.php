<?php

namespace App\Models;

use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Model;

class publisher extends Model
{
    protected $fillable = ['name', 'contact', 'email', 'address'];

    use HasSlug;

    public $timestamps = false;

    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    public function book()
    {
    	return $this->hasMany('App\Models\book', 'publisher_id');
    }
}
