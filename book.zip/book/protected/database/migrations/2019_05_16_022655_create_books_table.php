<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('title');
            $table->Integer('autor_id')->unsigned()->index();
            $table->Integer('publisher_id')->unsigned()->index();
            $table->text('sinopsis');
            $table->timestamps();


            $table->foreign('autor_id')->references('id')->on('autor');
            $table->foreign('publisher_id')->references('id')->on('publisher');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('books');
    }
}
