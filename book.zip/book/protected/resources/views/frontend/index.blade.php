<!DOCTYPE html>
<html>
<head>
    <title>Autor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style type="text/css">
    	
    </style>
</head>
<body>
   <!-- Header ********************************** -->
 	<div>
   		<div class="navbar navbar-light navbar-expand-md bg-light">
	   		<div class="navbar-brand">
	   		<label><h4>Refi</h4></label>
	   		<a href="">Home</a>
	   		<a href="">Book</a>
	   		<a href="">Autor</a>
	   		<a href="">Publisher</a>
	   		</div>
	   		<div class="">
	   		test2
	   		</div>
	   </div>
	</div>
   <!-- End Header ****************************** -->

   <!-- content ********************************* -->
   <!-- End content ***************************** -->

   <!-- footer ********************************** -->
   <!-- End footer ****************************** -->
</body>
</html>