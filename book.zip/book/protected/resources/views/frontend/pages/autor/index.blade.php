<!DOCTYPE html>
<html>
<head>
    <title>Autor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <style type="text/css">
        a{
            color: #28B463;
        }
        a.edit{
            padding-right: 20px;

        }
    </style>
</head>
<body>
    <div class="col-md-12" style="margin: 80px auto 0">
        <div class="col-md-8 mx-auto">
            <label class="display-4"><h3>Autors--</h3></label>
            <a href="{{url('autor/create')}}" class="btn btn-primary float-right">Add Autor</a>
        </div>
        <div class="col-md-8 mx-auto">
            <table class="table table-bordered">
                <thead class="bg-warning">
                    <tr>
                        <th class="text-center" scope="col">ID</th>
                        <th class="text-center" scope="col">Name</th>
                        <th class="text-center" scope="col">Email</th>
                        <th class="text-center" scope="col">Contact</th>
                        <th class="text-center" scope="col">Address</th>
                        <th class="text-center" scope="col" style="width: 14%">Action</th>
                    </tr>
                </thead>
                <tbody class="table-sm">
                    @if(isset($datas))
                    @foreach($datas as $data)
                    <tr>
                        <th class="text-center" scope="row">{{$data->id}}</th>
                        <th>{{$data->name}}</th>
                        <th>{{$data->email}}</th>
                        <th>{{$data->contact ?? '-'}}</th>
                        <th>{{$data->address ?? '-'}}</th>
                        <th>
                            <a href="{{url('autor/edit')}}/{{$data->id}}" class="edit">Edit</a>
                            <a href="{{url('autor/delete')}}/{{$data->id}}">Delete</a>
                        </th>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                        <th colspan="6">
                            <div class="text-center">Data Not Found</div>
                        </th>
                    </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>