<!DOCTYPE html>
<html>
<head>
    <title>Autor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="col-md-12" style="margin: 80px auto 0">
        <div class="col-md-8 mx-auto">
            <form method="POST" action="<?php echo e(url('publisher')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" hidden value="<?php echo e($data->id ?? ''); ?>">
                <div class="form-group">
                    <label>Name*</label>
                    <input type="text" name="name" class="form-control" required value="<?php echo e($data->name ?? ''); ?>">                    
                </div>
                <div class="form-group">
                    <label>Email*</label>
                    <input type="text" name="email" class="form-control" required value="<?php echo e($data->email ?? ''); ?>">                    
                </div>
                <div class="form-group">
                    <label>Contact*</label>
                    <input type="text" name="contact" class="form-control" required value="<?php echo e($data->contact ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Address*</label>
                    <textarea class="form-control" name="address" required><?php echo e($data->address ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" name="" class="form-control bg-primary text-light">
                </div>
            </form>  
        </div>
    </div>
</body>
</html><?php /**PATH D:\Laravel\book\protected\resources\views/frontend/pages/publisher/add.blade.php ENDPATH**/ ?>