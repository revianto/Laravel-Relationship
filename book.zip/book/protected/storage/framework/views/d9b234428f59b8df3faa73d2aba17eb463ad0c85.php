<!DOCTYPE html>
<html>
<head>
    <title>Autor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="col-md-12" style="margin: 80px auto 0">
        <div class="col-md-8 mx-auto">
            <form method="POST" action="<?php echo e(url('book')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" hidden value="<?php echo e($data->id ?? ''); ?>">
                <div class="form-group">
                    <label>Title*</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($data->title ?? ''); ?>" required>                    
                </div>
                <div class="form-group">
                    <label>Autor*</label>
                    <select class="form-control" required name="autor">
                        <?php if(isset($data)): ?>
                        <?php $__currentLoopData = $autors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($autor->id); ?>" <?php if($autor->id == $data->autor_id): ?> selected <?php endif; ?>><?php echo e($autor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <option>--</option>
                        <?php $__currentLoopData = $autors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($autor->id); ?>"><?php echo e($autor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Publisher*</label>
                    <select class="form-control" required name="publisher">
                        <?php if(isset($data)): ?>
                        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($publisher->id); ?>" <?php if($publisher->id == $data->publisher_id): ?> selected <?php endif; ?>><?php echo e($publisher->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        <?php else: ?>
                        <option>--</option>
                        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($publisher->id); ?>"><?php echo e($publisher->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Sinopsis</label>
                    <textarea class="form-control" name="sinopsis" required><?php echo e($data->sinopsis ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" name="" class="form-control bg-primary text-light">
                </div>
            </form>  
        </div>
    </div>
</body>
</html><?php /**PATH D:\Laravel\book\protected\resources\views/frontend/pages/book/add.blade.php ENDPATH**/ ?>